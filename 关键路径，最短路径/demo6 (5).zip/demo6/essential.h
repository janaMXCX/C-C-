#include "Set.h"

int CriticalPath(ALGraph G);
void run1();
