#include "Set.h"

void run2();

void printPath(AMGraph G, int v0);

void ShortestPath_DIJ(AMGraph G,int v0);
