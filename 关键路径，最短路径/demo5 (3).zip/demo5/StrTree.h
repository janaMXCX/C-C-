#ifndef SET_H_INCLUDED
#define SET_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <map>
#include <iostream>
#include <stack>
#include <queue>
#define OK 1
#define ERROR 0
#define OVERFLOW -2

#define INT_MAX 100;

using namespace std;

typedef struct{
    char sym;
    int weight;
    int parent,lchild,rchild;
}HTNode2,*HuffmanTree2;

//����Ȩֵ��С
void Select2(HuffmanTree2 HT, int n, int &s1, int &s2);
//��ʼ���Լ�����
void CreateHuffmanTree2(HuffmanTree2 &HT, int n, char characters[], int weights[]);
//����������
void GenerateHuffmanCodes(HuffmanTree2 HT, int n, std::map<char, std::string>& huffmanCodes);
//����
void run2();

#endif // MENU_H_INCLUDED
