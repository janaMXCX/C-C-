#include "StrTree.h"

int main()
{
    run2();
    return OK;
}
