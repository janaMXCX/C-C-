#include "Set.h"
#define MaxInt 32767
#define MVNum 100
typedef char VerTexType;
typedef int ArcType;


typedef struct ArchNode
{
    int adjvex;
    struct ArcNode * nextarc;
    int info;
}ArcNode;

typedef struct VNode
{
    VerTexType data;
    ArcNode *firstarc;
}VNode,AdjList[MVNum];

typedef struct
{
    AdjList vertices;
    int vexnum,arcnum;
}ALGraph;
