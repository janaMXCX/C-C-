#include "Set.h"

struct TreeNode2 {
    char data;
    TreeNode2* lchild;
    TreeNode2* rchild;
};

void Strata_orderTraversal(TreeNode2* root);
void CreateBinaryTree3(TreeNode2*& root);
void Strata_order_run();
